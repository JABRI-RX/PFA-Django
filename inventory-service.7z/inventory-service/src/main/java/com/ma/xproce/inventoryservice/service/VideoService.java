package com.ma.xproce.inventoryservice.service;

import com.ma.xproce.inventoryservice.entities.Video;
import com.ma.xproce.inventoryservice.repositories.VideoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class VideoService implements VideoManager{
//
    private VideoRepository videoRepository;
    @Override
    public Video addVideo(Video video) {
        try{
            return videoRepository.save(video);
        }
        catch (Exception exception)
        {
            return null;
        }
    }

    @Override
    public Video EditVideo(Video video) {
        return videoRepository.save(video);

    }

    @Override
    public Boolean DeleteVideo(Video video) {
        try{
            videoRepository.delete(video);
            return true;
        }catch (Exception exception)
        {
            return false;
        }
    }
    public Boolean DeleteVideoById(Integer id){
        try{
            videoRepository.deleteById(id);
            return true;
        }catch (Exception exception)
        {
            return false;
        }
    }
    public void DeleteAllVideos()
    {
        videoRepository.deleteAll();
    }
    @Override
    public List<Video> getAllVideos() {
        return videoRepository.findAll();
    }
}
