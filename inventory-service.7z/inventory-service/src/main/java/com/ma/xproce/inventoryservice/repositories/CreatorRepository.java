package com.ma.xproce.inventoryservice.repositories;

import com.ma.xproce.inventoryservice.entities.Creator;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreatorRepository extends JpaRepository<Creator,Integer> {

}
