package com.ma.xproce.inventoryservice.service;


import com.ma.xproce.inventoryservice.entities.Video;

import java.util.List;

public interface VideoManager   {
    public Video    addVideo(Video video);
    public Video    EditVideo(Video video);
    public Boolean  DeleteVideo(Video video);
    public List<Video> getAllVideos();

}
