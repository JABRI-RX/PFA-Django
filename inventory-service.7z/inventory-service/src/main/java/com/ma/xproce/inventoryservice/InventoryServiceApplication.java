package com.ma.xproce.inventoryservice;

import com.ma.xproce.inventoryservice.entities.Creator;
import com.ma.xproce.inventoryservice.entities.Video;
import com.ma.xproce.inventoryservice.repositories.CreatorRepository;
import com.ma.xproce.inventoryservice.repositories.VideoRepository;
import com.ma.xproce.inventoryservice.service.VideoManager;
import com.ma.xproce.inventoryservice.service.VideoService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class InventoryServiceApplication  {

    private VideoRepository videoRepository;
    private CreatorRepository creatorRepository;
    public static void main(String[] args) {
        SpringApplication.run(InventoryServiceApplication.class, args);
    }

    public CommandLineRunner start(VideoManager videoManager)
    {
        return args -> {

            Creator creator = new Creator();
              creator.setName("EPSTEIN");
            creator.setEmail("EPSTEIn@gmail.com");
            //creatorRepository.save(creator);
            Video vid = new Video();
            vid.setName("JEE Cour");
            vid.setDecription("Cour JAVA EE PART 1");
            vid.setURL("www.youtube.com/jee");
            vid.setCreator(creator);

            Video vid2 = new Video();
            vid.setName(">NET Cour");
            vid.setDecription("Cour .NET PART 1");
            vid.setURL("www.youtube.com/.net");
            vid.setCreator(creator);
            videoManager.addVideo(vid);
            videoManager.addVideo(vid2);
//
//            List<Video> videos = new ArrayList<>();
//            videos.add(vid);
//            videos.add(vid2);
//            creator.setVideos(videos);
//            videoRepository.save(vid);
//            videoRepository.save(vid2);

        }
    }
}
