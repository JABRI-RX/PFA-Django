package com.ma.xproce.inventoryservice.repositories;

import com.ma.xproce.inventoryservice.entities.Video;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideoRepository extends JpaRepository<Video,Integer> {
}
